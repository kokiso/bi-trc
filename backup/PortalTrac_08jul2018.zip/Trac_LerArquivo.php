<!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
    <title>Ler arquivo</title>
    <link rel="stylesheet" href="css/css2017.css">
    <link rel="stylesheet" href="css/cssTable2017.css">
    <link rel="stylesheet" href="css/cssFaTable.css">
    <script src="js/js2017.js"></script>
    <script src="js/jsTable2017.js"></script>
    <script language="javascript" type="text/javascript"></script>
    <style>
      .comboSobreTable {
        position:relative;
        float:left;
        display:block;
        overflow-x:auto;
        background-color:white;
        width:90em;
        height:5em;
        border:1px solid silver;
        border-radius: 6px 6px 6px 6px;
      }
    </style>  
    <script>
      "use strict";
      ////////////////////////////////////////////////
      // Executar o codigo após a pagina carregada  //
      ////////////////////////////////////////////////
      document.addEventListener("DOMContentLoaded", function(){ 
        //
        //
        //////////////////////////////////////////////
        // Montando a table para importar registros //
        //////////////////////////////////////////////
        jsLa={
          "titulo":[
             {"id":0  ,"field":"INICIO"     ,"labelCol":"INICIO"    ,"tamGrd":"8em"  ,"tamImp":"20"}
            ,{"id":1  ,"field":"FIM"        ,"labelCol":"FIM"       ,"tamGrd":"8em"  ,"tamImp":"20"}
            ,{"id":2  ,"field":"QTOS"       ,"labelCol":"QTOS"      ,"tamGrd":"5em"  ,"tamImp":"20"}
            ,{"id":3  ,"field":"TOT"        ,"labelCol":"TOT"       ,"tamGrd":"8em"  ,"tamImp":"20"}
            ,{"id":3  ,"field":"DAT"        ,"labelCol":"ULTIMA IMP","tamGrd":"15em" ,"tamImp":"20"}
            ,{"id":4  ,"field":"ERRO"       ,"labelCol":"ERRO"      ,"tamGrd":"25em" ,"tamImp":"50"}
          ]
          ,"botoesH":[
             {"texto":"Iniciar Importação"  ,"name":"laIniciar" ,"onClick":"7"  ,"enabled":true ,"imagem":"fa fa-print"            ,"ajuda":"Iniciar importação sistem sat" }        
            ,{"texto":"Parar Importação"    ,"name":"laParar"   ,"onClick":"7"  ,"enabled":true ,"imagem":"fa fa-close"            ,"ajuda":"Fechar formulario" }             
            ,{"texto":"Fechar"              ,"name":"laFechar"  ,"onClick":"7"  ,"enabled":true ,"imagem":"fa fa-close"            ,"ajuda":"Fechar formulario" }
          ] 
          ,"registros"      : []                        // Recebe um Json vindo da classe clsBancoDados
          //,"corLinha"       : "if(ceTr.cells[2].innerHTML !='OK') {ceTr.style.color='yellow';ceTr.style.backgroundColor='red';}"      
          ,"checarTags"     : "N"                       // Somente em tempo de desenvolvimento(olha as pricipais tags)                                
          ,"div"            : "frmLa"                   // Onde vai ser gerado a table
          ,"divFieldSet"    : "tabelaLa"                // Para fechar a div onde estão os fieldset ao cadastrar
          ,"form"           : "frmLa"                   // Onde vai ser gerado o fieldSet                     
          ,"divModal"       : "divTopoInicio"           // Nome da div que vai fazer o show modal
          ,"tbl"            : "tblLa"                   // Nome da table
          ,"prefixo"        : "la"                      // Prefixo para elementos do HTML em jsTable2017.js
          ,"tabelaBD"       : "*"                       // Nome da tabela no banco de dados  
          ,"width"          : "90em"                    // Tamanho da table
          ,"height"         : "48em"                    // Altura da table
          ,"tableLeft"      : "sim"                     // Se tiver menu esquerdo
          ,"relTitulo"      : "Importação"              // Titulo do relatório
          ,"relOrientacao"  : "P"                       // Paisagem ou retrato
          ,"indiceTable"    : "TAG"                     // Indice inicial da table
          ,"relFonte"       : "8"                       // Fonte do relatório
          ,"formName"       : "frmLa"                   // Nome do formulario para opção de impressão 
          ,"tamBotao"       : "20"                      // Tamanho botoes defalt 12 [12/25/50/75/100]
        }; 
        if( objLa === undefined ){          
          objLa=new clsTable2017("objLa");
        };  
        objLa.montarHtmlCE2017(jsLa);
        //
        //  
        //btnFiltrarClick("S");
        //buscarGrp();
      });
      //
      var objLa;                          // Obrigatório para instanciar o JS Ler Arquivo
      var jsLa;                           // Obrigatório para instanciar o objeto objLa
      var clsJs;                          // Classe responsavel por montar um Json e eviar PHP
      var clsErro;                        // Classe para erros            
      var fd;                             // Formulario para envio de dados para o PHP
      var msg;                            // Variavel para guardadar mensagens de retorno/erro 
      var retPhp                          // Retorno do Php para a rotina chamadora
      var numLinhas     = 0;              // Numero de linhas da table
      var contMsg       = 0;              // contador para mensagens
      var cmp           = new clsCampo(); // Abrindo a classe campos
      var totImportado  = 0;
      var emProcesso    = false;
      var jsPub         = JSON.parse(localStorage.getItem("lsPublico"));
      var qtosInterval;
      //
      function processar(){
        if( emProcesso==false ){
          emProcesso=true;
          clsJs   = jsString("lote");  
          clsJs.add("rotina"      , "lerSistemSat"                            );
          clsJs.add("login"       , jsPub[0].usr_login                        );
          clsJs.add("tot"         , totImportado                              );
          fd = new FormData();
          fd.append("integrar" , clsJs.fim());
          msg     = requestPedido("Trac_Integrar.php",fd); 
          retPhp  = JSON.parse(msg);
          if( retPhp[0].retorno == "OK" ){
            numLinhas = document.getElementById("tblLa").rows.length;
            if( numLinhas==15 ){
              objLa.limparTable();
              jsLa.registros=[];
            }
            jsLa.registros.push(retPhp[0]["dados"][0]);
            objLa.montarBody2017();
            totImportado+=(retPhp[0]["dados"][0][1]-retPhp[0]["dados"][0][0]);
          } else {
            gerarMensagemErro("Importar",retPhp[0].erro,"Erro");  
            emProcesso=true;
            return false;
          };
          emProcesso=false;          
        };
      };
      //
      function laIniciarClick(){
        qtosInterval=setInterval(function(){ 
          processar(); 
        }, 5000);
      }  
      function laPararClick(){
        clearInterval(qtosInterval);
      };  
      function laFecharClick(){
        window.parent.document.getElementById("iframeCorpo").src=""
      };
    </script>
  </head>
  <body>
    <div class="divTelaCheia" style="float:left;">
      <div id="divRotina" class="conteudo" style="display:block;overflow-x:auto;"> 
        <div id="divTopoInicio">
        </div>
        <form method="post" 
              name="frmLa" 
              id="frmLa" 
              class="frmTable" 
              action="classPhp/imprimirsql.php" 
              target="_newpage"
              style="top: 6em; width:77em;position: absolute; z-index:30;display:none;">
          <p class="frmCampoTit">
          <input class="informe" type="text" name="titulo" value="Importacao" disabled="" style="color: white; text-align: left;">
          </p>
        </form>
      </div>
    </div>       
  </body>
</html>